Shows a text that animates when highlighting or clicking on a cube.

## Editing

* Open this folder in VSCode.

## Building

* From inside VSCode: `Shift+Ctrl+B`
* From command line: `npm run build`

## Running

* From inside VSCode: `F5`
* From command line: `npm start`
